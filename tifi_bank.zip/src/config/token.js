export const TOKENS = [
  {
    address: "0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd",
    title: "BNB",
    description: "BNB",
  },
  {
    address: "0x8FAbF85E96DD40dE46E184268Cf4571402228b5B",
    title: "BUSD",
    description: "BUSD Token",
  },
  {
    address: "0x892d4c088562e2D3fcD4Cbd6CA699f7acA8F7D98",
    title: "TiFi",
    description: "TiFi Token",
  },
];
